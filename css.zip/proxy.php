<?php
/**
 * Ultra-Fast Proxy Redirector 2026
 * يتحمل 100 ألف مشاهد وأكثر (استهلاك صفر)
 */

error_reporting(0);

// مفتاح التشفير
$key = "MySecretKey2024";

// 1. فك التشفير
$data = $_GET['data'] ?? '';
if (empty($data)) {
    header("HTTP/1.1 404 Not Found");
    exit;
}

$bin = base64_decode($data);
$real_url = '';
for($i=0; $i<strlen($bin); $i++) {
    $real_url .= $bin[$i] ^ $key[$i % strlen($key)];
}

// 2. فلتر الحماية (السر في الـ 404)
$referer = $_SERVER['HTTP_REFERER'] ?? '';
$secFetchDest = $_SERVER['HTTP_SEC_FETCH_DEST'] ?? '';

// لو شخص كتب الرابط بيده في المتصفح أو فتحه في صفحة جديدة
// المتصفح هيرسل sec-fetch-dest كـ 'document'.. إحنا هنرفضه ونعطيه 404
if ($secFetchDest === 'document' || (empty($referer) && empty($secFetchDest))) {
    header("HTTP/1.1 404 Not Found");
    echo "<h1>404 Not Found</h1>";
    exit;
}

// 3. التحويل (Redirect)
// دي الطريقة اللي بتخلي السيرفر ميتعبش نهائياً
if (filter_var($real_url, FILTER_VALIDATE_URL)) {
    header("Location: " . $real_url, true, 302);
    exit;
}

header("HTTP/1.1 404 Not Found");